import unittest
import Account

class TestAccount(unittest.TestCase):
    
    # Two unit tests for Withdrawl
    def test_Withdrawl(self):
        account = Account.Account()
        account.balance = 100
        account.withdraw(25)
        self.assertEqual(account.balance, 75)
    
    def test_Withdrawl2(self):
        account = Account.Account()
        account.balance = 100
        self.assertFalse(account.withdraw(125))

    # Two unit tests for Deposit
    def test_Deposit(self):
        account = Account.Account()
        account.balance = 100
        self.assertFalse(account.deposit(-25))
        
    def test_Deposit2(self):
        account = Account.Account()
        account.balance = 100
        account.deposit(25)
        self.assertEqual(account.balance, 125)

    # Two unit tests for isValidPIN
    def test_isvValidPIN(self):
        account = Account.Account()
        account.pin = 1234
        self.assertTrue(account.isValidPIN(1234))

    def test_isValidPIN2(self):
        account = Account.Account()
        account.pin = 1234
        self.assertFalse(account.isValidPIN(4321))

if __name__ == '__main__':
    unittest.main()