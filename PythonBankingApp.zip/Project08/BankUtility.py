import random

class BankUtility:
    
    def promptUserForString(prompt):
        # implement promptUserForString here
        #         
        return "" # be sure to change this

    def promptUserForPositiveNumber(prompt):
        
        # implement promptUserForPositiveNumber here
        
        return 0.0 # be sure to change this
    
    def generateRandomInteger(min, max):
        # implement generateRandomInteger here
        return random.randint(min, max)
    
    def convertFromDollarsToCents(amount):        
        # implement convertFromDollarsToCents here
        return amount * 100
    
    def isNumeric(numberToCheck):
        try:
            if numberToCheck.isdigit():
                return True
            else:
                return False
        except ValueError:
            return False
