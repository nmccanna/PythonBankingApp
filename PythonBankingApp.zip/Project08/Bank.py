class Bank:
    def __init__(self):
        self.__Accounts = {}
        self.maxAccounts = 100
        
    # add account to bank
    def addAccountToBank(self, account):
        if len(self.__Accounts) >= self.maxAccounts:
            return False
        self.__Accounts[account.accountNumber] = account
        return True; 

    # remove account from bank
    def removeAccountFromBank(self, account):
        del self.__Accounts[account.accountNumber]
        return True; 
    
    # find account in bank
    def findAccount(self, accountNumber):
        if accountNumber in self.__Accounts:
            return self.__Accounts[accountNumber]
        else:
            return None
        
    # add interest to all accounts
    def addMonthlyInterest(self, percent):
       monthlyInterest = (percent / 12) / 100
       for account in self.__Accounts.values():
            account.balance += account.balance * monthlyInterest
