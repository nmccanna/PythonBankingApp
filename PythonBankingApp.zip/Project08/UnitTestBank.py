import unittest
import Bank
import Account

class TestBank(unittest.TestCase):
           
        # Two unit tests for findAccount
        def test_findAccount(self):
            bank = Bank.Bank()
            account = Account.Account()
            account.accountNumber = 12345678
            bank.addAccountToBank(account)
            self.assertEqual(bank.findAccount(12345678), account)

        def test_findAccount2(self):
            bank = Bank.Bank()
            account = Account.Account()
            account.accountNumber = 12345678
            bank.addAccountToBank(account)
            self.assertFalse(bank.findAccount(87654321), account)

        # Two unit tests for addAccountToBank
        def test_addAccountToBank(self):
            bank = Bank.Bank()
            account = Account.Account()
            account.accountNumber = 12345678
            bank.addAccountToBank(account)
            self.assertFalse(bank.findAccount(87654321), account)

        def test_addAccountToBank2(self):
            bank = Bank.Bank()
            account = Account.Account()
            account.accountNumber = 12345678
            bank.addAccountToBank(account)
            self.assertEqual(bank.findAccount(12345678), account)

        # Two unit tests for removeAccountFromBank
        def test_removeAccountFromBank(self):
            bank = Bank.Bank()
            account = Account.Account()
            account.accountNumber = 12345678
            bank.addAccountToBank(account)
            self.assertEqual(bank.findAccount(87654321), None)
        
        def test_removeAccountFromBank2(self):
            bank = Bank.Bank()
            account = Account.Account()
            account.accountNumber = 12345678
            bank.addAccountToBank(account)
            bank.removeAccountFromBank(account)
            self.assertEqual(bank.findAccount(12345678), None)

        # Two unit tests for addMonthlyInterest
        def test_addMonthlyInterest(self):
            bank = Bank.Bank()
            account = Account.Account()
            account.balance = 100
            bank.addAccountToBank(account)
            bank.addMonthlyInterest(12)
            self.assertNotEqual(account.balance, 100)
            
        def test_addMonthlyInterest2(self):
            bank = Bank.Bank()
            account = Account.Account()
            account.balance = 100
            bank.addAccountToBank(account)
            bank.addMonthlyInterest(12)
            self.assertEqual(account.balance, 101)

if __name__ == '__main__':
    unittest.main()