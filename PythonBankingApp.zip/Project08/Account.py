class Account:
    # add your attributes here
    def __init__(self):
        self.__firstName = ""
        self.__lastName = ""
        self.__ownerSSN = ""
        self.__accountNumber = 0
        self.__pin = 0
        self.__balance = 0.0

    # add methods as getters and setters for attributes
    @property
    def firstName(self):
        return self.__firstName
    
    @firstName.setter
    def firstName(self, firstName):
        self.__firstName = firstName

    @property
    def lastName(self):
        return self.__lastName
    
    @lastName.setter
    def lastName(self, lastName):
        self.__lastName = lastName

    @property
    def ownerSSN(self):
        return self.__ownerSSN
    
    @ownerSSN.setter
    def ownerSSN(self, ownerSSN):
        self.__ownerSSN = ownerSSN

    @property
    def accountNumber(self):
        return self.__accountNumber
    
    @accountNumber.setter
    def accountNumber(self, accountNumber):
        self.__accountNumber = accountNumber

    @property
    def pin(self):
        return self.__pin
    
    @pin.setter
    def pin(self, pin):
        self.__pin = pin

    @property
    def balance(self):
        return self.__balance
    
    @balance.setter
    def balance(self, balance):
        self.__balance = balance

    # toString method
    def toString(self):
        print("First Name:", self.__firstName)
        print("Last Name:", self.__lastName)
        print("SSN:", self.__ownerSSN)
        print("Account Number:", self.__accountNumber)
        print("PIN:", self.__pin)
        print("Balance:", self.__balance)

    # deposit method
    def deposit(self, deposit):
        # implement deposit here
        if deposit == 0:
            deposit = float(input("Enter the amount you want to deposit: "))
            if deposit < 0:
                print("Amount cannot be negative. Try again.")
                deposit = float(input("Enter the amount you want to deposit: "))
        self.__balance += deposit
        print(f"Your new balance is: ${self.__balance}")
    
    # withdraw method
    def withdraw(self, withdraw):
        # implement withdraw here
        success = False
        if withdraw == 0:
            withdraw = float(input("Enter the amount you want to withdraw: "))
        if withdraw < 0:
            print("Amount cannot be negative.")
        elif withdraw > self.__balance:
            print("Insufficient funds.")
        else:
            self.__balance -= withdraw
            print(f"Your new balance is: ${self.__balance}")
            success = True
        return success
    
    # isValidPIN method
    def isValidPIN(self, pin):
        # implement isValidPIN here
        if pin == self.__pin:
            return True
        else:    
            return False
    
    def __repr__(self):
        return "" # change this as needed

