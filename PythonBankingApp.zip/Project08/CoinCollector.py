
class CoinCollector:

    # constructor so you cannot instantiate this class
    def __init(self):
    
    def parseChange(coins):
       
        # implement parseChange here
        
        return 0
