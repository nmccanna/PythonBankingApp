

class BankManager:
    def __init__(self):
        # This is where you will implement your ‘main’ method and start
        # the program from.  The BankManager class should create an instance
        # of a Bank object when the program runs and use that instance to
        # manage the Accounts in the bank
       
    @staticmethod
    def promptForAccountNumberAndPIN(bank, accountNumber, PIN):
        accountNumber = input("Enter your account number: ")
        PIN = input("Enter your PIN: ")
    
        # implement promptForAccountNumberAndPIN here
        # takes one parameter, a Bank object that represents the bank.
        # The method should prompt the user to enter an account number
        # and then try to find a matching account with that account number
        # in the bank.
        
        return # be sure to change this as needed
