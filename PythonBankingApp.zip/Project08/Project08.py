import random
import Account
import Bank

# Main class
class BankManager:
    def __init__(self):
        # This is where you will implement your ‘main’ method and start
        # the program from.  The BankManager class should create an instance
        # of a Bank object when the program runs and use that instance to
        # manage the Accounts in the bank
        self.__bankOBJECT = Bank.Bank()

    # Prompt for account number and PIN
    @staticmethod
    def promptForAccountNumberAndPIN(bank):
        while True:
            accountNumber = input("Enter your account number: ")
            account = bank.findAccount(accountNumber)
            if account != None:
                break
            else:
                print(f"Account not found for account number: {accountNumber}")
                return None
        while True:
            PIN = input("Enter your PIN: ")
            if account.isValidPIN(PIN):
                break
            else:
                print("Invalid PIN")
                return None
        return account
    
    # Option 1 - Create Account
    def openAccount(self):
        firstName = input("Enter Account Owner's First Name: ")
        lastName = input("Enter Account Owner's Last Name: ")
        while True:
            ownerSSN = input("Enter Account Owner's SSN (9 digits): ")
            if len(ownerSSN) != 9:
                print("SSN must be 9 digits")
                continue
            else:
                break
        while True:
            accountNumber = str(random.randint(10000000, 99999999))
            if self.__bankOBJECT.findAccount(accountNumber) != None:
                continue
            break
        pin = str(random.randint(1000, 9999))
        balance = 0.0
        account = Account.Account()
        account.firstName = firstName
        account.lastName = lastName
        account.ownerSSN = ownerSSN
        account.accountNumber = accountNumber
        account.pin = pin
        account.balance = balance
        self.__bankOBJECT.addAccountToBank(account)
        print(f"Account created with account number {accountNumber} and PIN {pin}")
        print(account.toString())

    # Option 2 - Get Account Info and Balance
    def getAccountInfoAndBalance(self, account):
        if account != None:
            print(account.toString())
            return True
        return False
    
    # Option 3 - Change PIN
    def changePIN(self, account):
        while True:
            newPIN = input("Enter new PIN: ")
            if not newPIN.isdigit():
                print("PIN must be all digits, not letters or special characters.")
                continue
            if len(newPIN) != 4:
                print("PIN must be 4 digits")
                continue
            else:
                break
        account.pin = newPIN
        print("PIN changed")
        return True

    # Option 4 - Deposit Money
    def depositMoney(self, account):
        account.deposit(0)
    
    # Option 5 - Transfer Money
    def transferMoney(self, account):
        destAccountNumber = input("Enter account number to transfer to: ")
        destAccount = self.__bankOBJECT.findAccount(destAccountNumber)
        amount = float(input("Enter amount to transfer: "))
        if destAccount == None:
            print("Account not found")
            return False
        if amount > account.balance:
            print(f"Insufficient funds in account {account.accountNumber}")
            return False
        if amount < 0:
            print("Amount cannot be negative.")
            return False
        account.balance -= amount
        destAccount.balance += amount
        print("Transfer successful")
        print(f"New balance in {account.accountNumber}: ${account.balance}")
        print(f"New balance in {destAccount.accountNumber}: ${destAccount.balance}")
        return True
    
    # Option 6 - Withdraw Money
    def withdrawMoney(self, account):
        account.withdraw(0)

    # Option 7 - ATM Withdrawal
    def atmWithdrawal(self, account):
        while True:
            amount = int(input("Enter amount to withdraw in dollars (no cents) in multiples of $5 (limit $1000): "))
            if amount % 5 != 0:
                print("Invalid amount")
                continue
            if amount > account.balance:
                print("Insufficient funds")
                continue
            if amount > 1000:
                print("Amount exceeds limit")
                continue
            if amount < 0:
                print("Amount cannot be negative. Try again.")
                continue
            break
        numTwenties = amount // 20
        remainder = amount % 20
        amtTwenties = numTwenties * 20
        numTens = remainder // 10
        remainder = amount - amtTwenties - (numTens * 10)      
        numFives = remainder // 5
        account.balance -= amount
        print(f"Dispensing ${amount} in the following denominations:")
        print(f"{numTwenties} in twenties")
        print(f"{numTens} in tens")
        print(f"{numFives} in fives")
        return True
        

    # Option 8 - Deposit Change
    def depositChange(self, account):
        print("Enter P for penny")
        print("Enter N for nickel")
        print("Enter D for dime")
        print("Enter Q for quarter")
        print("Enter H for half-dollar")
        print("Enter W for whole dollar")

        coinString = input("Deposit change: ")
        total = 0
        for coin in range(0, len(coinString)):
            match(coinString[coin]):
                case "P":
                    total += 1
                case "N":
                    total += 5
                case "D":
                    total += 10
                case "Q":
                    total += 25
                case "H":
                    total += 50
                case "W":
                    total += 100
                case default:
                    print(f"Invalid coin(s): {coinString[coin]}")
                    continue
        totalBalance = float(total)/100
        account.deposit(totalBalance)
        print("Deposit successful")
        print(f"${totalBalance} in coins deposited into account")
        print(f"New Balance: ${account.balance}")
        return True
    

    # Option 9 - Close Account
    def closeAccount(self, account):
        self.__bankOBJECT.removeAccountFromBank(account)
        print("Account closed")
        return True
    
    
    # Option 10 - Add Monthly Interest
    def addMonthlyInterest(self):
        annualInterest = float(input("Enter annual interest rate percentage: "))
        self.__bankOBJECT.addMonthlyInterest(annualInterest)
    
    # Print Menu
    def PrintMenu(self):
        print("What do you want to do?")
        print("1. Open an account")
        print("2. Get account information and balance")
        print("3. Change PIN")
        print("4. Deposit money in account")
        print("5. Transfer money between accounts")
        print("6. Withdraw money from account")
        print("7. ATM withdrawal")
        print("8. Deposit change")
        print("9. Close an account")
        print("10. Add monthly interest to all accounts")
        print("11. End Program")

    # Main
    def main(self):
        while True:
            self.PrintMenu()
            choice = input("Enter your choice: ")
            match choice:
                case "1":
                    print("Open an account")
                    self.openAccount()
                case "2":
                    print("Get account information and balance")
                    account = self.promptForAccountNumberAndPIN(self.__bankOBJECT)
                    self.getAccountInfoAndBalance(account)
                case "3":
                    print("Change PIN")
                    account = self.promptForAccountNumberAndPIN(self.__bankOBJECT)
                    self.changePIN(account)
                case "4":
                    print("Deposit money in account")
                    account = self.promptForAccountNumberAndPIN(self.__bankOBJECT)
                    self.depositMoney(account)
                case "5":
                    print("Transfer money between accounts")
                    account = self.promptForAccountNumberAndPIN(self.__bankOBJECT)
                    self.transferMoney(account)
                case "6":
                    print("Withdraw money from account")
                    account = self.promptForAccountNumberAndPIN(self.__bankOBJECT)
                    self.withdrawMoney(account)
                case "7":
                    print("ATM withdrawal")
                    account = self.promptForAccountNumberAndPIN(self.__bankOBJECT)
                    self.atmWithdrawal(account)
                case "8":
                    print("Deposit change")
                    account = self.promptForAccountNumberAndPIN(self.__bankOBJECT)
                    self.depositChange(account)
                case "9":
                    print("Close an account")
                    account = self.promptForAccountNumberAndPIN(self.__bankOBJECT)
                    self.closeAccount(account)
                case "10":
                    print("Add monthly interest to all accounts")
                    account = self.promptForAccountNumberAndPIN(self.__bankOBJECT)
                    self.addMonthlyInterest()
                case "11":
                    print("End Program")
                    quit()
                case _:
                    print("Invalid choice")
                    continue
        
if __name__ == "__main__":
    obj = BankManager()
    obj.main()
